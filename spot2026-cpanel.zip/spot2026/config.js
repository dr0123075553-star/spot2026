// Spot 2026 settings. You can edit this file in cPanel (File Manager > right-click > Edit).
// 1) Application form: paste the Google Apps Script web app URL (ends in /exec) between the quotes.
//    Leave it empty and the Apply page asks students to apply on goon.edu.my instead.
window.SPOT_FORM_URL = "";
// 2) Live exam news: the site loads the latest daily news from here, so you do not need to re-upload every day.
//    Set it to "" to turn this off.
window.SPOT_LIVE_NEWS = "https://dr0123075553-star.github.io/spot2026/updates.json";
